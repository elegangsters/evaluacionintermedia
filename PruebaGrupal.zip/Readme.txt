                                             


                                            CONTEXTO DEL PROBLEMA
          
          

              leyes y normativas que obligan a las empresas a tomar todas las medidas necesarias para proteger
          la vida y salud de los trabajadores. Para dar cumplimiento a la normativa y mantener ambientes
          de trabajo seguros, muchas empresas se ven en la obligación de contratar asesoría profesional,
          lo cual representa un costo elevado y fomenta la disminución o la no implementación de medidas
          necesarias para la seguridad. Muchas de las empresas que han optado por no invertir en asesoría
          preventiva, se ven expuestas a aplicación de multas de las entidades fiscalizadoras, gastos por
          días perdidos en accidentabilidad, bajas en la producción, alzas en el pago de cotizaciones (al
          organismo administrador del seguro de accidentes del trabajo, ley 16.744), entre otros. Además,
          hay que considerar posibles demandas y pagos de indemnizaciones a los trabajadores y familiares
          afectados por accidentes del trabajo.
          
                                                     
                La empresa no posee un sistema de información que le permita administrar toda la cantidad de
          información que se genera, ni controlar las actividades y el recurso humano. Existen problemas
          con la planificación de las visitas, generalmente los profesionales están en terreno por lo que no
          están disponibles para informarles sus actividades futuras. No existe registro del profesional que
          ha estado con mayor actividad ni se sabe dónde está cada uno.
          Las visitas a terreno a veces no tienen el efecto indicado por la falta de coordinación con el cliente.
          Asisten trabajadores que no tienen que ver con la charla, o bien, no se coordina la ejecución de
          la capacitación, lo que trae consigo multas para la empresa. No se tiene un control de los clientes
          que pagan y los que no, lo que hace que muchas actividades de los profesionales corran por
          cuenta de la empresa, generando desbalances financieros. Las actividades se registran en
          carpetas lo que dificulta el seguimiento de las asesorías y el resumen de resultados por empresa.
                Además, generalmente no se cumplen ciertas actividades de control de implementación de
          soluciones y a veces no se ha cumplido con la dirección del trabajo, lo que genera multas para los
          clientes, bajando la calidad del servicio. Los profesionales que han atendido la empresa
          esporádicamente han variado, no existiendo un registro de la totalidad de actividades preventivas
          realizadas y no se tiene certeza de los avances.


                                                 NUESTRA SOLUCION
                  
            
                 El objetivo de nuestro sistema de información es brindar a sus usuarios una plataforma de fácil 
          acceso en las que manejar los procesos internos relacionados a la prevención de riesgos, considerando una 
          interfaz fluida e intuitiva que permita agilizar las actividades diarias de cada usuario asociado a nuestra 
          organización.Ademas,nuestro sistema está enfocado tanto para los profesionales y administrativos que 
          participan directamente de los diferentes procesos de la empresa, así como también para los clientes 
          que contraten nuestroS servicios.
           
                ¿Qué procesos considera la plataforma?
            
                 Actualmente, nuestra plataforma considera los procesos relacionados a las capacitaciones, visitas 
          en terreno,investigación de accidentes, apllicación de chequeos y seguimiento de mejoras propuestas a 
          aquellos clientes que contraten nuestros servicios.
                 Este servicio finalmente
          pretende ofrecer una solución completa en prevención de riesgos para las empresas a un costo
          razonable, cumpliendo estrictamente todos los procesos necesarios para dar cumplimiento a la
          normativa vigente, mejorando los ambientes de trabajo, la productividad, contribuyendo a un
          ahorro económico.

